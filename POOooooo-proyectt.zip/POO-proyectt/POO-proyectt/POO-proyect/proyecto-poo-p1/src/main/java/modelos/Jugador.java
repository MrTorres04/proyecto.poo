package modelos;

import java.util.ArrayList;

public class Jugador extends Usuario implements Participante{
    private String nombre;
    private String apellidos;
    private String DNI;
    private int ranking;
    private double puntuacion;
    private Emparejamiento emparejamiento;
    private final Usuario creador;
    private ArrayList<Estadistica> estadisticas;




    public Jugador(String nombre,String apellidos,String dni,Usuario creador){
        super(nombre.toLowerCase() + "_" + apellidos.toLowerCase(),
                apellidos.toLowerCase() + nombre.toLowerCase() + "754",
                nombre.toLowerCase() + "." + apellidos.toLowerCase() + "@jugadores.upm.es",
                TipoUsuario.JUGADOR);
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.DNI= dni;
        this.estadisticas = inicializarEstadisticas();
        this.creador = creador;
    }

    public Jugador(String nombre,String apellidos,String dni,Usuario creador,String nombreUsuario,
                  String mail,String pasword){
        super(nombreUsuario,mail,pasword,TipoUsuario.JUGADOR);
        this.nombre= nombre;
        this.apellidos = apellidos;
        this.DNI= dni;
        //this.estadisticas = initializeStatistics();
        this.creador= creador;
    }
    public String getNombre()
    {
        return nombre;
    }
    private ArrayList<Estadistica> inicializarEstadisticas() {
        ArrayList<Estadistica> estadisticas = new ArrayList<>();
        for (Categoria categoria : Categoria.values()) {
            estadisticas.add(new Estadistica(categoria, 0.0));
        }
        return estadisticas;
    }

    public double obtenerValorEstadistica(Categoria categoria) {
        for (int i = 0; i < estadisticas.size(); i++) {
            Estadistica estadistica = estadisticas.get(i);
            if (estadistica.getCategoria() == categoria) {
                return estadistica.getValor();
            }
        }
        return 0.0;
    }

    public void establecerValorEstadistica(Categoria categoria, double valor) {
        for (Estadistica estadistica : estadisticas) {
            if (estadistica.getCategoria() == categoria) {
                estadistica.setValor(valor);
                return;
            }
        }
    }
    public double getEstadistica(Categoria categoria){
        for (int i = 0; i < estadisticas.size(); i++) {
            Estadistica estadistica = estadisticas.get(i);
            if (estadistica.getCategoria() == categoria) {
                return estadistica.getValor();
            }
        }
        return 0.0;
    }

    public double getPuntuacion()
    {
        return puntuacion;
    }
    public Emparejamiento getEmparejamiento()
    {
        return emparejamiento;
    }
    public void setNombre(String nombre)
    {
        this.nombre=nombre;
    }
    public void setPuntuacion(double puntuacion)
    {
        if (puntuacion >= 0.0)
        {
            this.puntuacion = puntuacion;
        } else {
            System.out.println("Error: La puntuación no puede ser menor que 0.0");
        }
    }
    public boolean estaParticipando(ListaTorneo listaTorneos) {
        int i = 0;
        Torneo torneo = listaTorneos.getTorneo(i);  // Obtener el torneo de la lista
        while (torneo != null) {
            int j = 0;
            Participante participante = torneo.getParticipante(j);  // Obtener el participante del torneo
            while (participante != null) {
                if (torneo.estaActivo() && participante.equals(this)) {  // Verificar si el torneo está activo y si el participante es este jugador
                    return true;
                }
            }
        }
        return false;  // Si no se encuentra en ningún torneo activo, retorna falso
    }


    @Override
    public double getValorEstadistica(Categoria categoria) {
        return 0;
    }

    @Override
    public boolean isParticipating(ListaTorneo listaTorneo) {
        return false;
    }
        @Override
        public int getRanking() {
            return ranking;
        }

}
