package modelos;
import java.util.ArrayList;


public class ListaUsuarios {
    private final ArrayList<Usuario> items;


    public ListaUsuarios() {
        this.items = new ArrayList<>();
    }
    public void agregarUsuario(Usuario usuario) {
        assert usuario != null;
        if (!items.contains(usuario)) {
            items.add(usuario);
        }
    }
    public void eliminarUsuario(Usuario usuario) {
        assert usuario != null;
        if (items.contains(usuario)) {
            items.remove(usuario);
        }
    }
    public Usuario buscarPorNombre(String nombreUsuario) {
        for (Usuario usuario : items) {
            if (usuario.getNombre().equalsIgnoreCase(nombreUsuario)) {
                return usuario;
            }
        }
        return null;
    }
    public void mostrarTodos() {
        for (Usuario usuario : items) {
            System.out.println(usuario);
        }
    }

}
