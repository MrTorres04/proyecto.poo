package modelos;

public enum Categoria {
    PUNTOS_ANOTADOS("Puntos Marcados"),
    TORNEOS_GANADOS("Partidos ganados"),
    ASISTENCIAS("Puntos de asistencia"),
    PARTIDOS_GANADOS("Torneos ganados en el pasado"),
    DINERO_GENERADO("Dinero generado en el torneo");


    private final String categoria;

    private Categoria(String categoria) {
        assert categoria != null;
        this.categoria = categoria;
    }

    public String getCategory(){
        return categoria;
    }
}
