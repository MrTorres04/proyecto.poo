package vistas.comandos;
import vistas.Comando;
import modelos.ListaJugadores;
import modelos.ListaEquipo;
import modelos.Usuario;
import modelos.Jugador;
import modelos.Equipo;

public class CrearEquipo extends Comando {
    private final ListaEquipo listaEquipos;
    private final ListaJugadores listaJugadores;

    public CrearEquipo(ListaEquipo listaEquipos, ListaJugadores listaJugadores) {
        super("equipo-crear");
        this.listaEquipos = listaEquipos;
        this.listaJugadores = listaJugadores;
    }

    @Override
    public void ejecutar(String[] args) {  // El usuario ya no se pasa como parámetro
        assert args.length >= 4 : "Error: No se han proporcionado suficientes argumentos.";

        // Obtener el usuario actual desde el Singleton
        Usuario usuario = UsuarioSesion.getUsuarioActual();  // Ahora se obtiene globalmente

        String nombreEquipo = args[1].toLowerCase();
        String nombreJugador1 = args[2].toLowerCase();
        String nombreJugador2 = args[3].toLowerCase();

        // Verificar si el equipo ya existe
        if (listaEquipos.buscarPorNombre(nombreEquipo) != null) {
            System.out.println("Error: El equipo ya existe.");
            return;
        }

        // Buscar jugadores
        Jugador jugador1 = listaJugadores.buscarPorNombre(nombreJugador1);
        Jugador jugador2 = listaJugadores.buscarPorNombre(nombreJugador2);

        if (jugador1 == null || jugador2 == null) {
            System.out.println("Error: Uno o ambos jugadores no se encontraron.");
            return;
        }

        // Crear el equipo y agregarlo a la lista de equipos
        Equipo equipo = new Equipo(nombreEquipo, jugador1, jugador2, usuario);
        listaEquipos.agregarEquipo(equipo);

        System.out.println("Equipo creado con éxito.");
    }
}
