package modelos;
import java.util.ArrayList;
import java.util.List;

public class ListaJugadores {
        private final List<Jugador> jugadores;

        public ListaJugadores() {
            this.jugadores = new ArrayList<>();
        }

        public void agregarJugador(Jugador jugador) {
            assert jugador != null : "Error: El jugador no puede ser nulo.";
            if (!jugadores.contains(jugador)) {
                jugadores.add(jugador);
            }
        }

        public void eliminarJugador(Jugador jugador) {
            assert jugador != null : "Error: El jugador no puede ser nulo.";
            if (jugadores.contains(jugador)) {
                jugadores.remove(jugador);
            }
        }

        public Jugador buscarPorNombre(String nombre) {
            assert nombre != null && !nombre.isEmpty() : "Error: El nombre no puede ser nulo o vacío.";
            for (Jugador jugador : jugadores) {
                if (jugador.getNombre().equalsIgnoreCase(nombre)) {
                    return jugador;
                }
            }
            return null; // Si no se encuentra
        }

        public Jugador buscarPorUsuario(Usuario usuario) {
            assert usuario != null : "Error: El usuario no puede ser nulo.";
            String nombreUsuario = usuario.getNombre();
            for (Jugador jugador : jugadores) {
                if (jugador.getNombre().equalsIgnoreCase(nombreUsuario)) {
                    return jugador;
                }
            }
            return null; // Si no se encuentra
        }

        public void mostrarTodos() {
            if (jugadores.isEmpty()) {
                System.out.println("No hay jugadores en la lista.");
                return;
            }
            for (Jugador jugador : jugadores) {
                System.out.println(jugador);
            }
        }

        public boolean contieneJugador(Jugador jugador) {
            assert jugador != null : "Error: El jugador no puede ser nulo.";
            return jugadores.contains(jugador);
        }


}

