package vistas.comandos;
import modelos.*;
import vistas.Comando;


public class InscribirEnTorneo extends Comando {
    private final ListaTorneo listaTorneos;
    private final ListaJugadores listaJugadores;
    private final ListaEquipo listaEquipos;

    public InscribirEnTorneo(ListaTorneo listaTorneos, ListaJugadores listaJugadores, ListaEquipo listaEquipos) {
        super("torneo-agregar");
        this.listaTorneos = listaTorneos;
        this.listaJugadores = listaJugadores;
        this.listaEquipos = listaEquipos;
    }

    @Override
    public void ejecutar(String[] args) {
        Usuario usuarioActual = UsuarioSesion.getUsuarioActual();
        if (usuarioActual == null) {
            System.out.println("No hay un usuario autenticado.");
            return;
        }
        Jugador jugador = listaJugadores.buscarPorUsuario(usuarioActual);
        if (jugador == null) {
            System.out.println("Jugador no encontrado.");
            return;
        }
        String nombreTorneo = args[1].toLowerCase();
        Torneo torneo = listaTorneos.buscarPorNombre(nombreTorneo);

        if (torneo != null) {
            if (args.length == 2) {
                torneo.agregarParticipante(jugador);
                System.out.println("Jugador añadido al torneo con éxito.");
            }
            else if (args.length == 3) {
                String nombreEquipo = args[2].toLowerCase();
                Equipo equipo = listaEquipos.buscarPorNombre(nombreEquipo);
                if (equipo != null && equipo.estaEnEquipo(jugador)) {
                    torneo.agregarParticipante(equipo);
                    System.out.println("Equipo añadido al torneo con éxito.");
                } else {
                    System.out.println("Equipo no encontrado o el jugador no pertenece a este equipo.");
                }
            }
        } else {
            System.out.println("Torneo no encontrado.");
        }
    }
}
