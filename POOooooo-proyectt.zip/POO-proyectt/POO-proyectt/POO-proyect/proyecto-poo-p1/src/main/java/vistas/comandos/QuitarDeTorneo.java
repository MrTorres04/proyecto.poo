package vistas.comandos;

import vistas.Comando;
import modelos.ListaTorneo;
import modelos.ListaJugadores;
import modelos.Usuario;
import modelos.Jugador;
import modelos.Torneo;
import modelos.Participante;

public class QuitarDeTorneo extends Comando {
    private final ListaTorneo listaTorneos;
    private final ListaJugadores listaJugadores;

    public QuitarDeTorneo(ListaTorneo listaTorneos, ListaJugadores listaJugadores) {
        super("torneo-eliminar");
        this.listaTorneos = listaTorneos;
        this.listaJugadores = listaJugadores;
    }

    @Override
    public void ejecutar(String[] args) {
        Usuario usuarioActual = UsuarioSesion.getUsuarioActual();
        if (usuarioActual == null) {
            System.out.println("No hay un usuario autenticado.");
            return;
        }
        Jugador jugador = listaJugadores.buscarPorUsuario(usuarioActual);
        if (jugador == null) {
            System.out.println("Jugador no encontrado.");
            return;
        }
        String nombreTorneo = args[1].toLowerCase();
        Torneo torneo = listaTorneos.buscarPorNombre(nombreTorneo);

        if (torneo != null) {
            if (args.length == 2) {
                torneo.quitarParticipante(jugador);
                System.out.println("Jugador eliminado del torneo con éxito.");
            } else {
                System.out.println("El jugador no estaba inscrito en este torneo.");
            }
        } else if (args.length == 3) {
            String nombreEquipo = args[2].toLowerCase();
            Participante participante = torneo.getParticipante(nombreEquipo);
            if (participante != null) {
                torneo.quitarParticipante(participante);
                System.out.println("Equipo eliminado del torneo con éxito.");
            } else {
                System.out.println("Equipo no encontrado o el jugador no pertenece a este equipo.");
            }
        } else {
            System.out.println("Torneo no encontrado.");
        }
    }
}
