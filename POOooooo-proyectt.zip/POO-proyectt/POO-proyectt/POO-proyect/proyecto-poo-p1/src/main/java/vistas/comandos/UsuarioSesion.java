package vistas.comandos;
import modelos.Usuario;

public class UsuarioSesion {
    private static Usuario usuarioActual;

    // Obtener el usuario actual
    public static Usuario getUsuarioActual() {
        if (usuarioActual == null) {
            throw new IllegalStateException("No hay un usuario autenticado.");
        }
        return usuarioActual;
    }

    // Establecer el usuario actual (iniciar sesión)
    public static void setUsuarioActual(Usuario usuario) {
        usuarioActual = usuario;
    }

    // Cerrar sesión (eliminar el usuario actual)
    public static void cerrarSesion() {
        if (usuarioActual == null) {
            throw new IllegalStateException("No hay un usuario autenticado para cerrar sesión.");
        }
        usuarioActual = null;  // Desconectamos al usuario
        System.out.println("Sesión cerrada con éxito.");
    }

    // Verificar si hay un usuario autenticado (sesión activa)
    public static boolean haySesionActiva() {
        return usuarioActual != null;
    }
}
