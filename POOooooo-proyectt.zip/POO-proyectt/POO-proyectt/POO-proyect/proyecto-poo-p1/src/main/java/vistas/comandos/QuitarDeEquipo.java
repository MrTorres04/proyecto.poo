package vistas.comandos;

import vistas.Comando;
import modelos.ListaEquipo;
import modelos.Equipo;
import modelos.Jugador;

public class QuitarDeEquipo extends Comando {
    private final ListaEquipo listaEquipos;

    public QuitarDeEquipo(ListaEquipo listaEquipos) {
        super("equipo-eliminar-jugador");
        this.listaEquipos = listaEquipos;
    }

    public void ejecutar(String[] args) { //nombre jugador, nombre equipo
        assert args.length >= 3 : "Error: No se han proporcionado suficientes argumentos.";

        String nombreJugador = args[1].toLowerCase();
        String nombreEquipo = args[2].toLowerCase();

        Equipo equipo = listaEquipos.buscarPorNombre(nombreEquipo);
        if (equipo != null) {
            Jugador jugador = equipo.obtenerJugador(nombreJugador);
            if (jugador != null) {
                equipo.eliminarJugador(jugador);
                System.out.println("Jugador eliminado del equipo");
            } else {
                System.out.println("El jugador no pertenece al equipo");
            }
        } else {
            System.out.println("Equipo no encontrado");
        }
    }
}

