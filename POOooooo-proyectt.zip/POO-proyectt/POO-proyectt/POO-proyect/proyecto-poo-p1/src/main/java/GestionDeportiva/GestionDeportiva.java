package GestionDeportiva;

import modelos.GestionJugadores;
import modelos.ListaEquipo;
import modelos.ListaParticipantes;
import modelos.ListaTorneo;
import vistas.GestorComandos;
import vistas.ListaComandos;
import modelos.Jugador;

public class GestionDeportiva {
    private final GestorComandos gestorComandos;
    private final ListaEquipo listaEquipo;
    private final ListaComandos listaComandos;
    private final ListaParticipantes listaParticipantes;
    private final ListaTorneo listaTorneo;


    public GestionDeportiva(){
        this.listaTorneo = new ListaTorneo();
        this.listaEquipo= new ListaEquipo();
        this.listaComandos= new ListaComandos();
        this.gestorComandos = new GestorComandos();
        this.listaParticipantes= new ListaParticipantes();
        this.cargarDatos();
    }

    public void execute(){
        do{
            gestorComandos.iniciar();
        }while(!gestorComandos.salida());
    }

    public static void main(String[] args) {
        new GestionDeportiva().execute();
    }
    private void inicializar(){
        Jugador jugador1 = new Jugador("Diego", "Álvarez", "01762345H", null);
        Jugador jugador2 = new Jugador("Valeria", "Méndez", "34829167K", null);
        Jugador jugador3 = new Jugador("Santiago", "Navarro", "52837492M", null);
        Jugador jugador4 = new Jugador("Lucía", "Santana", "21745890P", null);
        Jugador jugador5 = new Jugador("Mateo", "Fuentes", "30741925R", null);
        Jugador jugador6 = new Jugador("Camila", "Ríos", "12753846V", null);
        Jugador jugador7 = new Jugador("Luis", "Guerrero", "48293016W", null);
        Jugador jugador8 = new Jugador("Emma", "Blanco", "58321047L", null);
        Jugador jugador9 = new Jugador("Hugo", "Vidal", "70123984F", null);
        Jugador jugador10 = new Jugador("Paula", "Castillo", "37492015Q", null);
        Jugador jugador11 = new Jugador("Daniel", "Cortés", "91234780Z", null);
        Jugador jugador12 = new Jugador("Carla", "Serrano", "61928347Y", null);
        Jugador jugador13 = new Jugador("Leonardo", "Herrera", "40821975A", null);
        Jugador jugador14 = new Jugador("Isabela", "Campos", "83049267B", null);


    }
    private void cargarDatos(){
        inicializar();
    }


}




