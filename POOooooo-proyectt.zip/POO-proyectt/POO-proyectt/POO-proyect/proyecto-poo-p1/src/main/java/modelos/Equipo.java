package modelos;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;

public class Equipo implements Participante {
    private String nombre;
    private ArrayList<Jugador> jugadores;
    private ArrayList<Estadistica> estadisticas;
    private int ranking;
    private final Usuario creador;

    public Equipo(String nombre, Jugador jug1, Jugador jug2, Usuario creador) {
        super();
        this.nombre = nombre;
        jugadores= new ArrayList<>();
        jugadores.add(jug1);
        jugadores.add(jug2);
        this.estadisticas= inicializar();
        this.creador=creador;

    }

    public String getNombre() {
        return nombre;
    }

    @Override
    public double getValorEstadistica(Categoria categoria) {
        return 0;
    }

    @Override
    public boolean isParticipating(ListaTorneo listaTorneo) {
        return false;
    }
    // Implementa getRanking()
    @Override
    public int getRanking() {
        return ranking;
    }

    public boolean agregarJugador(Jugador jugador) {
        if (jugador == null) {
            throw new IllegalArgumentException("El jugador no puede ser nulo.");
        }
        return jugadores.add(jugador);
    }
    public boolean eliminarJugador(Jugador jugador) {
        if (jugador == null) {
            throw new IllegalArgumentException("El jugador no puede ser nulo.");
        }
        return jugadores.remove(jugador);
    }
    public Set<Jugador> getJugadores() {
        return new HashSet<>(jugadores);
    }
    private ArrayList<Estadistica> inicializar() {
        ArrayList<Estadistica> stats = new ArrayList<>();
        for (Categoria category : Categoria.values()) {
            stats.add(new Estadistica(category, 0.0));
        }
        return stats;
    }

    public double calcularEstadisticaEquipo(Categoria categoria) {
            for (int i = 0; i < estadisticas.size(); i++) {
                Estadistica estadistica = estadisticas.get(i);
                if (estadistica.getCategoria() == categoria) {
                    return estadistica.getValor();
                }
            }
            return 0.0;
        }

    @Override
    public String toString() {
        return "Equipo: " + nombre + ", Jugadores: " + jugadores.size();
    }
    public double obtenerValorEstadistica(Categoria categoria) {
        for (int i = 0; i < estadisticas.size(); i++) {
            Estadistica estadistica = estadisticas.get(i);
            if (estadistica.getCategoria() == categoria) {
                return estadistica.getValor();
            }
        }
        return 0.0;
    }

    private void establecerValorEstadistica(Categoria categoria, double valor) {
        for (Estadistica estadistica : estadisticas) {
            if (estadistica.getCategoria() == categoria) {
                estadistica.setValor(valor);
                return;
            }
        }
    }

    public boolean estaEnEquipo(Jugador jugador) {
        for (Jugador jugadorEnLista : jugadores) {
            if (jugadorEnLista == jugador) {
                return true;
            }
        }
        return false;
    }

    public Jugador obtenerJugador(String nombreJugador) {
        int indice = 0;
        Jugador jugador = jugadores.get(indice);
        while (jugador != null) {
            if (jugador.getNombre().equals(nombreJugador)) {
                return jugador;
            }
        }
        return null;
    }

    public boolean estaParticipando(ListaTorneo listaTorneos) {
        int i = 0;
        Torneo torneo = listaTorneos.getTorneo(i);
        while (torneo != null) {
            int j = 0;
            Participante participante = torneo.getParticipantes().get(j);
            while (participante != null) {
                if (torneo.estaActivo() && participante.equals(this)) {
                    return true;
                }
            }
        }
        return false;
    }

}
