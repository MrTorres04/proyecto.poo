package vistas.comandos;

import vistas.Comando;
import modelos.*;
public class MostrarEstadisticas extends Comando {
    private final ListaJugadores listaJugadores;

    public MostrarEstadisticas(ListaJugadores listaJugadores){
        super("mostrar-estadisticas");
        this.listaJugadores = listaJugadores;
    }

    public void ejecutar(String[] args) {
        String formato = args[1].toLowerCase();
        Usuario usuarioActual = UsuarioSesion.getUsuarioActual(); // Obtenemos el usuario actual

        // Buscamos al jugador relacionado con el usuario actual
        Jugador jugador = listaJugadores.buscarPorUsuario(usuarioActual);

        if (formato.equals("-csv")) {
            mostrarEstadisticasComoCSV(jugador);
        }
        else if (formato.equals("-json")) {
            mostrarEstadisticasComoJSON(jugador);
        }
        else {
            System.out.println("Formato incorrecto");
        }
    }

    private void mostrarEstadisticasComoCSV(Jugador jugador) {
        System.out.println("Nombre,Puntos Anotados,Partidos Ganados,Asistencias,Dinero Generado,Torneos Ganados");
        System.out.printf("%s,%d,%d,%d,%.2f,%d%n",
                jugador.getNombre(),
                jugador.obtenerValorEstadistica(Categoria.PUNTOS_ANOTADOS),
                jugador.obtenerValorEstadistica(Categoria.PARTIDOS_GANADOS),
                jugador.obtenerValorEstadistica(Categoria.ASISTENCIAS),
                jugador.obtenerValorEstadistica(Categoria.DINERO_GENERADO),
                jugador.obtenerValorEstadistica(Categoria.TORNEOS_GANADOS));
    }

    private void mostrarEstadisticasComoJSON(Jugador jugador) {
        System.out.println("{");
        System.out.println("  \"Nombre\": \"" + jugador.getNombre() + "\",");
        System.out.println("  \"Puntos Anotados\": " + jugador.obtenerValorEstadistica(Categoria.PUNTOS_ANOTADOS) + ",");
        System.out.println("  \"Partidos Ganados\": " + jugador.obtenerValorEstadistica(Categoria.PARTIDOS_GANADOS) + ",");
        System.out.println("  \"Asistencias\": " + jugador.obtenerValorEstadistica(Categoria.ASISTENCIAS) + ",");
        System.out.println("  \"Dinero Generado\": " + jugador.obtenerValorEstadistica(Categoria.DINERO_GENERADO) + ",");
        System.out.println("  \"Torneos Ganados\": " + jugador.obtenerValorEstadistica(Categoria.TORNEOS_GANADOS));
        System.out.println("}");
    }
}

