package vistas.comandos;

import modelos.*;
import vistas.Comando;
import java.util.Comparator;
import java.util.ArrayList;

public class ListarTorneos extends Comando {
    private final ListaTorneo listaTorneos;

    public ListarTorneos(ListaTorneo listaTorneos) {
        super("torneo-listar");
        this.listaTorneos = listaTorneos;
    }

    @Override
    public void ejecutar(String[] args) {
        Usuario usuarioActual = UsuarioSesion.getUsuarioActual();

        // Si no hay usuario autenticado,participantes aleatorios
        if (usuarioActual == null) {
            this.mostrarAleatorio();
        } else {
            // Si el usuario es un jugador,  ordenados por ranking
            if (usuarioActual.getTipoUsuario() == TipoUsuario.JUGADOR) {
                this.mostrarPorRanking();
            }
            // Si el usuario es un administrador
            if (usuarioActual.getTipoUsuario() == TipoUsuario.ADMINISTRADOR) {
                this.ejecutarAdministrador();
            }
        }
    }


    public void mostrarAleatorio() {
        int i = 0;
        Torneo torneo = listaTorneos.getTorneo(i);
        while (torneo != null) {
            System.out.println("===== Torneo =====\n" +
                    "Nombre: " + torneo.getNombre() + "\n" +
                    "Liga: " + torneo.getLiga() + "\n" +
                    "Deporte: " + torneo.getDeporte() + "\n" +
                    "Participantes: ");
            int j = 0;
            Participante participante = torneo.getParticipante(j);
            while (participante != null) {
                System.out.println("- " + participante.getNombre());
                j++;
                participante = torneo.getParticipante(j);
            }
            i++;
            torneo = listaTorneos.getTorneo(i);
        }
    }


    public void mostrarPorRanking() {
        int i = 0;
        Torneo torneo = listaTorneos.getTorneo(i);
        while (torneo != null) {
            System.out.println("===== Torneo =====\n" +
                    "Nombre: " + torneo.getNombre() + "\n" +
                    "Liga: " + torneo.getLiga() + "\n" +
                    "Deporte: " + torneo.getDeporte() + "\n" +
                    "Participantes: ");
            int j = 0;
            Participante participante = torneo.getParticipante(j);
            ArrayList<Participante> participantes = new ArrayList<>();
            while (participante != null) {
                participantes.add(participante);
                j++;
                participante = torneo.getParticipante(j);
            }

            for (int l = 0; l < participantes.size(); l++) {
                for (int m = 0; m < participantes.size() - l - 1; m++) {
                    Participante p1 = participantes.get(m);
                    Participante p2 = participantes.get(m + 1);

                    if (p1.getRanking() > p2.getRanking()) {
                        // Intercambiar los elementos
                        participantes.set(m, p2);
                        participantes.set(m+ 1, p1);
                    }
                }
            }

            for (Participante p : participantes) {
                System.out.println( p.getNombre() );
            }
            i++;
            torneo = listaTorneos.getTorneo(i);
        }
    }

    // Ejecuta las acciones de administrador: elimina torneos finalizados y muestra los torneos por ranking
    public void ejecutarAdministrador() {
        int index = 0;
        Torneo torneo = listaTorneos.getTorneo(index);
        while (torneo != null) {
            // Si el torneo está finalizado, lo eliminamos
            if (torneo.estaActivo()) {
                listaTorneos.eliminarTorneo(torneo);
                System.out.println("Torneo finalizado eliminado: " + torneo.getNombre());
            }
            index++;
            torneo = listaTorneos.getTorneo(index);
        }

        // Después de eliminar torneos finalizados, mostramos los torneos por ranking
        this.mostrarPorRanking();
    }
}

