package vistas;



import java.util.ArrayList;

public class TiposComandos {
    private String tipoUsuario;  // Tipo de usuario (ejemplo: "administrador", "usuario")
    private ArrayList<Comando> comandos;  // Lista de comandos disponibles

    // Constructor
    public TiposComandos(String tipoUsuario) {
        this.tipoUsuario = tipoUsuario;
        this.comandos = new ArrayList<>();
    }

    // Método para agregar un comando a la lista
    public void agregarComando(Comando comando) {
        comandos.add(comando);
    }

    // Método para obtener un comando por su nombre
    public Comando obtenerComandoPorNombre(String nombre) {
        for (Comando comando : comandos) {
            if (comando.obtenerComando().equalsIgnoreCase(nombre)) {
                return comando;
            }
        }
        return null;
    }

    // Obtener el tipo de usuario
    public String obtenerTipoUsuario() {
        return tipoUsuario;
    }

    // Convertir el tipo de usuario a String
    public String obtenerTipoUsuarioComoString() {
        return tipoUsuario;
    }

    // Obtener todos los comandos de esta lista
    public ArrayList<Comando> obtenerComandos() {
        return comandos;
    }
}

