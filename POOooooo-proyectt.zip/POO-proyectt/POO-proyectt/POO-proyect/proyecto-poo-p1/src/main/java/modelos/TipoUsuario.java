package modelos;

public enum TipoUsuario {
    JUGADOR("Jugador"),
    ADMINISTRADOR("Administrador");
    private final String tipoUsuario;

    private TipoUsuario(String tipoUsuario){
        this.tipoUsuario = tipoUsuario;
    }

}
