package modelos;

public class Usuario {
    protected String nombre;
    protected String contrasena;
    protected String email;

    private final TipoUsuario tipoUsuario;


    public TipoUsuario getTipoUsuario() {
        return tipoUsuario;
    }

    public Usuario (String nombre, String contrasena, String email, TipoUsuario tipoUsuario) {
        this.nombre = nombre;
        this.contrasena = contrasena;
        this.tipoUsuario = tipoUsuario;
        this.email=email;
    }

    public String getNombre() {
        return nombre;
    }
//si no lo pide borrar

    public boolean validarPassword(String contrasena) {
        return this.contrasena.equals(contrasena);
    }
    public boolean validarCredenciales(String email,String contrasena){
        if (this.email== email && this.contrasena == contrasena){
            return true;
        }
        return false;
    }
}
