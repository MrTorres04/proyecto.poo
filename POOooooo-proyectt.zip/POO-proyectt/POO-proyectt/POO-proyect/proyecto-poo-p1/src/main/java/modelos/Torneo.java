package modelos;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Torneo {

    private String nombre;
    private LocalDate fechaInicio;
    private LocalDate fechaFin;
    private String liga;
    private final ArrayList<Participante> listaParticipantes;
    private String deporte;
    private Categoria categoriaRankeo;
    private boolean inscripcionesCerradas;

    private List<Participante> participantes;
    private List<Emparejamiento> emparejamientos;

    public Torneo(String nombre, LocalDate fechaInicio, LocalDate fechaFin, String liga, String deporte) {
        this.nombre = nombre;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
        this.liga = liga;
        this.deporte = deporte;
        categoriaRankeo = categoriaRankeo;
        this.emparejamientos = new ArrayList<>();
        this.inscripcionesCerradas = false;
        listaParticipantes = new ArrayList<>();
    }

    public void inscribirParticipante(Participante participante) {
        if (inscripcionesCerradas) {
            throw new IllegalStateException("No se pueden inscribir participantes, las inscripciones están cerradas.");
        }
        if (!participantes.contains(participante)) {
            participantes.add(participante);
        }
    }

    public void cerrarInscripciones() {
        this.inscripcionesCerradas = true;
    }

    public void emparejarParticipantesManual(Participante p1, Participante p2) {
        if (!inscripcionesCerradas) {
            throw new IllegalStateException("No se pueden emparejar hasta que las inscripciones estén cerradas.");
        }
        if (!participantes.contains(p1) || !participantes.contains(p2)) {
            throw new IllegalArgumentException("Ambos participantes deben estar inscritos en el torneo.");
        }
        emparejamientos.add(new Emparejamiento(p1, p2));
    }

    public void emparejarParticipantesAleatorio() {
        if (!inscripcionesCerradas) {
            throw new IllegalStateException("No se pueden emparejar hasta que las inscripciones estén cerradas.");
        }
        if (participantes.size() % 2 != 0) {
            throw new IllegalStateException("El número de participantes debe ser par para realizar emparejamientos aleatorios.");
        }
        Collections.shuffle(participantes);
        for (int i = 0; i < participantes.size(); i += 2) {
            emparejamientos.add(new Emparejamiento(participantes.get(i), participantes.get(i + 1)));
        }
    }
    public boolean estaActivo() {
        LocalDate hoy = LocalDate.now();
        return (hoy.isAfter(fechaInicio) || hoy.isEqual(fechaInicio)) && hoy.isBefore(fechaFin);
    }


    public List<Participante> rankearParticipantes() {
        List<Participante> ranking = new ArrayList<>(participantes);
        ranking.sort((p1, p2) -> Double.compare(p2.getValorEstadistica(categoriaRankeo), p1.getValorEstadistica(categoriaRankeo)));
        return ranking;
    }


    public String getNombre() {
        return nombre;
    }

    public LocalDate getFechaInicio() {
        return fechaInicio;
    }

    public LocalDate getFechaFin() {
        return fechaFin;
    }

    public String getLiga() {
        return liga;
    }

    public String getDeporte() {
        return deporte;
    }

    public Categoria getCategoriaRankeo() {
        return categoriaRankeo;
    }

    public List<Participante> getParticipantes() {
        return participantes;
    }

    public List<Emparejamiento> getEmparejamientos() {
        return emparejamientos;
    }

    public boolean isInscripcionesCerradas() {
        return inscripcionesCerradas;
    }
    public Participante getParticipante(String name){
        for(Participante participant1 : listaParticipantes){
            if(participant1.getNombre() == name){
                return participant1;
            }
        }
        return null;
    }
    public void agregarParticipante(Participante participant){
        listaParticipantes.add(participant);
    }

    public Participante getParticipante(int i){
        return listaParticipantes.get(i);
    }
    public void limpiar(){
        listaParticipantes.clear();
    }
    public void quitarParticipante(Participante participant){
        listaParticipantes.remove(participant);
    }
    public void nuevoEmparejamiento(Participante participant1, Participante participant2){
        emparejamientos.add(new Emparejamiento(participant1,participant2));
    }
}
