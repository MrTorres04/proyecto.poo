package vistas.comandos;
import vistas.Comando;
import modelos.ListaJugadores;
import modelos.ListaTorneo;
import modelos.Usuario;
import modelos.Jugador;
public class BorrarJugador extends Comando {
    private final ListaJugadores listaJugadores;
    private final ListaTorneo listaTorneos;

    public BorrarJugador(ListaJugadores listaJugadores, ListaTorneo listaTorneos) {
        super("jugador-eliminar");
        this.listaJugadores = listaJugadores;
        this.listaTorneos = listaTorneos;
    }

    @Override
    public void ejecutar(String[] args) { // Argumentos: jugadorName
        assert args.length >= 2 : "Error: No se ha proporcionado el nombre del jugador.";

        // Obtener el usuario actual desde el Singleton
        Usuario usuario = UsuarioSesion.getUsuarioActual();  // Obtiene el usuario actual

        String nombreJugador = args[1].toLowerCase();  // Nombre del jugador en minúsculas
        Jugador jugador = listaJugadores.buscarPorNombre(nombreJugador);  // Buscar al jugador

        if (jugador != null) {
            // Verificar si el jugador está participando en algún torneo
            if (!jugador.estaParticipando(listaTorneos)) {
                listaJugadores.eliminarJugador(jugador);  // Eliminar jugador de la lista
                System.out.println("Jugador eliminado con éxito: " + nombreJugador);
            } else {
                System.out.println("El jugador está participando en un torneo en curso y no puede ser eliminado.");
            }
        } else {
            System.out.println("Error: Jugador no encontrado.");
        }
    }
}

