package modelos;

import java.util.ArrayList;
import java.util.List;

public class ListaParticipantes {
    private final List<Participante> items;

    public ListaParticipantes() {
        this.items = new ArrayList<>();
    }

    // Agregar un participante a la lista
    public void agregarParticipante(Participante participante) {
        assert participante != null;
        if (!items.contains(participante)) {
            items.add(participante);
        }
    }

    // Eliminar un participante de la lista
    public void eliminarParticipante(Participante participante) {
        assert participante != null;
        if (items.contains(participante)) {
            items.remove(participante);
        }
    }

    // Buscar un participante por nombre
    public Participante buscarPorNombre(String nombre) {
        for (Participante participante : items) {
            if (participante.getNombre().equalsIgnoreCase(nombre)) {
                return participante;  // Si el nombre coincide, devuelve el participante
            }
        }
        return null;  // Si no se encuentra el participante, devuelve null
    }

    // Mostrar todos los participantes de la lista
    public void mostrarTodos() {
        for (Participante participante : items) {
            System.out.println(participante);
        }
    }

    // Método adicional para obtener todos los participantes
    public List<Participante> obtenerTodos() {
        return items;
    }
}
