package vistas;

public abstract class Comando {
        private String nombreComando;
        public Comando(String nombreComando) {
            this.nombreComando = nombreComando;
        }
        public abstract void ejecutar(String[] args);
        public String obtenerComando() {
            return nombreComando;
        }

}
