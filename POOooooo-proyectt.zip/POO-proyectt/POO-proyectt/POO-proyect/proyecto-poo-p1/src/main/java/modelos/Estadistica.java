package modelos;

public class Estadistica {
    private Categoria categoria;
    private double valor;
    public Estadistica(Categoria categoria, double valor) {
        this.categoria = categoria;
        this.valor = valor;
    }
    public Categoria getCategoria() {
        return categoria;
    }

    public void setCategoria(Categoria categoria) {
        this.categoria = categoria;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    @Override
    public String toString() {
        return categoria.getCategory() + ": " + valor;  // Usar el método getCategory() del enum
    }

}
