package vistas.comandos;

import modelos.Usuario;
import vistas.Comando;
import vistas.comandos.UsuarioSesion;

public class CerrarSesion extends Comando {
    public CerrarSesion(){
        super("logout");
    }

    public void ejecutar(String[] args){
        if (UsuarioSesion.haySesionActiva()) {
            UsuarioSesion.cerrarSesion();
            System.out.println("Sesión cerrada exitosamente.");
        } else {
            System.out.println("No hay sesión activa.");
        }
    }
}
