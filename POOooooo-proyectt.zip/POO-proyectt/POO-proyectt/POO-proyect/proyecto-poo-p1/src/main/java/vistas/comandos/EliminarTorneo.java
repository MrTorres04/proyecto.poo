package vistas.comandos;

import vistas.Comando;
import modelos.Torneo;
import modelos.ListaTorneo;

public class EliminarTorneo extends Comando {
    private final ListaTorneo listaTorneos;

    public EliminarTorneo(ListaTorneo listaTorneos) {
        super("torneo-eliminar");
        this.listaTorneos = listaTorneos;
    }

    public void ejecutar(String[] args) {
        assert args.length >= 2 : "Error: No se ha proporcionado el nombre del torneo.";

        String nombre = args[1].toLowerCase();
        Torneo torneo = listaTorneos.buscarPorNombre(nombre);

        if (torneo != null) {
            listaTorneos.eliminarTorneo(torneo);
            System.out.println("Torneo eliminado con éxito");
        } else {
            System.out.println("Torneo no encontrado");
        }
    }
}
