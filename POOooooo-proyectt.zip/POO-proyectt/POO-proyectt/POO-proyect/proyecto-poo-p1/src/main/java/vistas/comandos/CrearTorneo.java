package vistas.comandos;

import vistas.Comando;
import modelos.ListaTorneo;
import java.time.LocalDate;
import modelos.Torneo;
import java.time.format.DateTimeParseException;
import java.time.format.DateTimeFormatter;

public class CrearTorneo extends Comando {
    private final ListaTorneo listaTorneos;
    private LocalDate parsearFecha(String fecha) {
        try {
            DateTimeFormatter formateador = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            return LocalDate.parse(fecha, formateador);
        } catch (DateTimeParseException e) {
            return null;
        }
    }
    public CrearTorneo(ListaTorneo listaTorneos) {
        super("torneo-crear");
        this.listaTorneos = listaTorneos;
    }

    public void ejecutar(String[] args) {
        assert args.length >= 6 : "Error: No se han proporcionado suficientes argumentos.";

        String nombreTorneo = args[1].toLowerCase();
        String inicio = args[2].toLowerCase();
        String fin = args[3].toLowerCase();
        String liga = args[4].toLowerCase();
        String deporte = args[5].toLowerCase();

        LocalDate fechaInicio = parsearFecha(inicio);
        LocalDate fechaFin = parsearFecha(fin);

        Torneo torneo = new Torneo(nombreTorneo, fechaInicio, fechaFin, liga, deporte);

        if (listaTorneos.buscarPorNombre(nombreTorneo) == null) {
            listaTorneos.agregarTorneo(torneo);
            System.out.println("Torneo creado con éxito");
        } else {
            System.out.println("Torneo ya existente");
        }
    }


}