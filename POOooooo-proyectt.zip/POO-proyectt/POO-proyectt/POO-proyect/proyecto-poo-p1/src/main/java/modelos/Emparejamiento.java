package modelos;


public class Emparejamiento
{
    private Participante participante1;
    private Participante participante2;
    public Emparejamiento(Participante participante1, Participante participante2) {
        this.participante1 = participante1;
        this.participante2 = participante2;
    }
    public Participante getParticipante1()
    {
        return participante1;
    }
    public Participante getParticipante2()
    {
        return participante2;
    }

    public String toString() {
        return participante1 + " vs " + participante2;
    }
}