package modelos;

import java.util.LinkedList;
import java.util.List;

public class GestionJugadores
{

    private  LinkedList<Jugador> jugadores;
    private List<Emparejamiento> emparejamientos;

    public GestionJugadores()
    {
        jugadores = new LinkedList<>();
        emparejamientos = new LinkedList<>();
    }

    public Jugador getJugadoresPorName(String nombre)
    {
        for (Jugador jugador : this.jugadores)
        {
            if (jugador.getNombre().equals(nombre))
                return jugador;
        }
        return null;

    }
    public LinkedList<Jugador> getJugadores()
    {
        return this.jugadores;
    }





    public void mostrarJugadores()
    {
        for (Jugador jugador : this.jugadores)
        {
            System.out.println(jugador.getNombre());
        }
    }
    public void establecerPuntuacion(String nombre, double puntuacion)
    {//esto pq te piden que crees jugadores solo con el
        //nomre!!
        for (Jugador jugador : this.jugadores)
        {
            if (jugador.getNombre().equals(nombre))
            {
                jugador.setPuntuacion(puntuacion);
            }
        }
    }
    public void rankearJugadores()
    {
        if (this.jugadores.isEmpty())
        {
            System.out.println("No hay jugadores para mostrar.");
        } else {
            List<Jugador> jugadoresCopia = new LinkedList<>(this.jugadores);

            // un bubble para odrenar
            for (int i = 0; i < jugadoresCopia.size() - 1; i++)
            {
                for (int j = 0; j < jugadoresCopia.size() - i - 1; j++)
                {
                    if (jugadoresCopia.get(j).getPuntuacion() < jugadoresCopia.get(j + 1).getPuntuacion())
                    {
                        Jugador temp = jugadoresCopia.get(j);
                        jugadoresCopia.set(j, jugadoresCopia.get(j + 1));
                        jugadoresCopia.set(j + 1, temp);
                    }
                }
            }
            for (Jugador jugador : jugadoresCopia)
            {
                System.out.println(jugador.getNombre() + ": " + jugador.getPuntuacion());
            }
        }
    }
}
