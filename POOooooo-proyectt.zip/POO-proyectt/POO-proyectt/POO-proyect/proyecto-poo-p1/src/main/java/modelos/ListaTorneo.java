package modelos;

import java.util.ArrayList;
import java.util.List;

public class ListaTorneo {

    private final List<Torneo> torneos;

    public ListaTorneo() {
        this.torneos = new ArrayList<>();
    }

    // Método para agregar un torneo a la lista
    public void agregarTorneo(Torneo torneo) {
        if (torneo != null && !torneos.contains(torneo)) {
            torneos.add(torneo);
        }
    }

    // Método para eliminar un torneo de la lista
    public void eliminarTorneo(Torneo torneo) {
        if (torneo != null && torneos.contains(torneo)) {
            torneos.remove(torneo);
        }
    }

    // Método para buscar un torneo por su nombre
    public Torneo buscarPorNombre(String nombre) {
        for (Torneo torneo : torneos) {
            if (torneo.getNombre().equalsIgnoreCase(nombre)) {
                return torneo;
            }
        }
        return null;
    }

    // Método para buscar torneos por deporte
    public List<Torneo> buscarPorDeporte(String deporte) {
        List<Torneo> torneosEncontrados = new ArrayList<>();
        for (Torneo torneo : torneos) {
            if (torneo.getDeporte().equalsIgnoreCase(deporte)) {
                torneosEncontrados.add(torneo);
            }
        }
        return torneosEncontrados;
    }

    // Método para mostrar todos los torneos
    public void mostrarTodos() {
        for (Torneo torneo : torneos) {
            System.out.println(torneo.toString());
        }
    }

    // Método para mostrar torneos activos (inscripciones abiertas)
    public void mostrarTorneosActivos() {
        for (Torneo torneo : torneos) {
            if (!torneo.isInscripcionesCerradas()) {
                System.out.println(torneo.getNombre() + " - Inscripciones abiertas");
            }
        }
    }

    // Obtener todos los torneos como lista
    public List<Torneo> obtenerTodos() {
        return new ArrayList<>(torneos); // Devuelve una copia para evitar modificaciones externas
    }
    public Torneo getTorneo(int i) {
        if (i >= 0 && i < torneos.size()) {
            return torneos.get(i); // Devuelve el torneo en la posición i
        } else {
            throw new IndexOutOfBoundsException("Índice fuera de los límites de la lista de torneos.");
        }
    }

}
