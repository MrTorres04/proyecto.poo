package vistas.comandos;
import modelos.ListaJugadores;
import modelos.ListaEquipo;
import modelos.Jugador;
import modelos.Equipo;
import vistas.Comando;

public class AñadirAEquipo extends Comando {
    private final ListaEquipo listaEquipos;
    private final ListaJugadores listaJugadores;

    public AñadirAEquipo(ListaEquipo listaEquipos, ListaJugadores listaJugadores) {
        super("añadir-equipo");
        this.listaEquipos = listaEquipos;
        this.listaJugadores = listaJugadores;
    }

    @Override
    public void ejecutar(String[] args) {
        String nombreJugador = args[1];
        String nombreEquipo = args[2];
        Jugador jugador = listaJugadores.buscarPorNombre(nombreJugador);
        Equipo equipo = listaEquipos.buscarPorNombre(nombreEquipo);

        if (jugador != null && equipo != null) {
            if (!equipo.estaEnEquipo(jugador)) {
                equipo.agregarJugador(jugador);
                System.out.println("Jugador inscrito con éxito");
            } else {
                System.out.println("El jugador ya pertenece al equipo");
            }
        } else {
            System.out.println("Jugador o equipo no encontrados");
        }
    }

}
