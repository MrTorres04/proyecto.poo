package vistas;

import java.util.Scanner;


import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class GestorComandos {

    private final Map<String, Comando> comandos;
    private final Scanner scanner;
    private boolean esc;
    // Constructor
    public GestorComandos() {
        comandos = new HashMap<>();
        scanner = new Scanner(System.in);
    }


    public void registrarComando(Comando comando) {
        comandos.put(comando.obtenerComando(), comando);
    }


    public void ejecutarComando(String nombreComando, String[] args) {
        Comando comando = comandos.get(nombreComando.toLowerCase());
        if (comando != null) {
            comando.ejecutar(args);
        } else {
            System.out.println("Comando no encontrado: " + nombreComando);
        }
    }

    public void iniciar() {
        String input;
        do {
            System.out.print("Ingrese un comando (o 'salir' para terminar): ");
            input = scanner.nextLine().trim();

            if ("salir".equalsIgnoreCase(input)) {
                break;
            }

            String[] partes = input.split(" ");
            String nombreComando = partes[0].toLowerCase();
            String[] args = new String[partes.length - 1];

            System.arraycopy(partes, 1, args, 0, args.length);

            ejecutarComando(nombreComando, args);

        } while (true);
    }
    public boolean salida(){
        return esc;
    }
}