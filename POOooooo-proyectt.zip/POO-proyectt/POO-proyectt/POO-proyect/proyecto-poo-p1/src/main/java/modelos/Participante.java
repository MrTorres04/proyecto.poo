package modelos;

public interface Participante  {


    String getNombre();
    public abstract double getValorEstadistica(Categoria categoria);
    int getRanking();
    boolean isParticipating(ListaTorneo listaTorneo);
}
