package modelos;

import java.util.ArrayList;

public class ListaEquipo {
    // Lista interna de equipos
    private final ArrayList<Equipo> items;

    // Constructor
    public ListaEquipo() {
        this.items = new ArrayList<>();
    }

    // Método para agregar un equipo a la lista
    public void agregarEquipo(Equipo equipo) {
        assert equipo != null : "El equipo no puede ser nulo.";
        if (!items.contains(equipo)) {
            items.add(equipo);
        }
    }

    // Método para eliminar un equipo de la lista
    public void eliminarEquipo(Equipo equipo) {
        assert equipo != null : "El equipo no puede ser nulo.";
        if (items.contains(equipo)) {
            items.remove(equipo);
        }
    }

    // Método para buscar un equipo por su nombre
    public Equipo buscarPorNombre(String nombre) {
        for (Equipo equipo : items) {
            if (equipo.getNombre().equalsIgnoreCase(nombre)) {
                return equipo;
            }
        }
        return null;
    }

    // Método para mostrar todos los equipos de la lista
    public void mostrarTodos() {
        for (Equipo equipo : items) {
            System.out.println(equipo);
        }
    }
}
