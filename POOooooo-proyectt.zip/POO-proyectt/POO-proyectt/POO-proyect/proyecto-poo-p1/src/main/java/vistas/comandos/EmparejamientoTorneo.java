package vistas.comandos;
import java.util.Scanner;

import vistas.Comando;
import modelos.Torneo;
import modelos.ListaTorneo;
import modelos.Participante;

public class EmparejamientoTorneo extends Comando {
    private final ListaTorneo listaTorneos;
    private final Scanner scanner;

    public EmparejamientoTorneo(ListaTorneo listaTorneos) {
        super("torneo-emparejamiento");
        this.listaTorneos = listaTorneos;
        scanner = new Scanner(System.in);
    }

    public void ejecutar(String[] args) { // -m -a; nombre torneo
        assert args.length >= 3 : "Error: No se han proporcionado suficientes argumentos.";

        String tipoEmparejamiento = args[1].toLowerCase();
        String nombreTorneo = args[2].toLowerCase();
        Torneo torneo = listaTorneos.buscarPorNombre(nombreTorneo);

        if (torneo != null && torneo.estaActivo()) {
            if (tipoEmparejamiento.equals("-a")) {
                torneo.emparejarParticipantesAleatorio();
            } else if (tipoEmparejamiento.equals("-m")) {
                torneo.limpiar();/////////////////////////////////////////////////////
                Participante participante1 = pedirParticipante(torneo);
                Participante participante2 = pedirParticipante(torneo);
                torneo.nuevoEmparejamiento(participante1, participante2);
            }
        } else {
            System.out.println("Torneo no encontrado o torneo no activo");
        }
    }

    private Participante pedirParticipante(Torneo torneo) {
        String input;
        Participante participante = null;
        do {
            System.out.print("Ingrese el nombre de un participante: ");
            input = scanner.nextLine().trim();
            participante = torneo.getParticipante(input);
        } while (participante == null); // Corrige la condición: se repite si el participante no se encuentra
        return participante;
    }
}
