package vistas.comandos;

import modelos.ListaUsuarios;
import modelos.Usuario;
import vistas.Comando;

public class IniciarSesion extends Comando {
    private final ListaUsuarios listaUsuarios;

    public IniciarSesion(ListaUsuarios listaUsuarios) {
        super("login");
        this.listaUsuarios = listaUsuarios;
    }

    @Override
    public void ejecutar(String[] args) {

        String nombreUsuario = args[1];
        String correo = args[2];
        String contrasena = args[3];
        Usuario usuario = listaUsuarios.buscarPorNombre(nombreUsuario);
        if (usuario != null && usuario.validarCredenciales(correo, contrasena)) {
            System.out.println("Inicio de sesión exitoso.");
        } else {
            System.out.println("Credenciales incorrectas.");
        }
    }
}

