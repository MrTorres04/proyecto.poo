package vistas.comandos;
import modelos.ListaEquipo;
import modelos.Equipo;
import modelos.ListaTorneo;
import vistas.Comando;

public class BorrarEquipo extends Comando {
    private final ListaEquipo listaEquipos;
    private final ListaTorneo listaTorneos;

    public BorrarEquipo(ListaEquipo listaEquipos, ListaTorneo listaTorneos) {
        super("equipo-eliminar");
        this.listaEquipos = listaEquipos;
        this.listaTorneos = listaTorneos;
    }

    public void ejecutar(String[] args) {
        assert args.length >= 2 : "Error: Falta el nombre del equipo.";

        String nombre = args[1].toLowerCase();  // Nombre del equipo a eliminar
        Equipo equipo = listaEquipos.buscarPorNombre(nombre);

        if (equipo != null) {
            // Verificar si el equipo está participando en algún torneo
            if (!equipo.estaParticipando(listaTorneos)) {
                listaEquipos.eliminarEquipo(equipo);
                System.out.println("Equipo eliminado con éxito");
            } else {
                System.out.println("El equipo está participando en un torneo en curso y no se puede eliminar");
            }
        } else {
            System.out.println("Equipo no encontrado");
        }
    }
}
