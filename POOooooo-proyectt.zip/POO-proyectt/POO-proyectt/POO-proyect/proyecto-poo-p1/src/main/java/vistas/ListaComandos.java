package vistas;

import java.util.ArrayList;

public class ListaComandos {

    // Lista interna de elementos (en este caso, listas de comandos)
    private final ArrayList<TiposComandos> items;

    // Constructor
    public ListaComandos() {
        this.items = new ArrayList<>();
    }

    // Método para agregar un elemento (en este caso, una lista de comandos)
    public void agregarItem(TiposComandos item) {
        assert item != null;
        if (!items.contains(item)) {
            items.add(item);
        }
    }

    // Método para eliminar un elemento
    public void eliminarItem(TiposComandos item) {
        assert item != null;
        if (items.contains(item)) {
            items.remove(item);
        }
    }


    public TiposComandos buscarPorNombre(String tipoUsuario) {
        for (TiposComandos commandsList : items) {
            if (commandsList.obtenerTipoUsuarioComoString().equalsIgnoreCase(tipoUsuario)) {
                return commandsList;
            }
        }
        return null;
    }

    public void mostrarTodos() {
        for (TiposComandos item : items) {
            System.out.println(item);
        }
    }
}
