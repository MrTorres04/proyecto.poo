package vistas.comandos;
import modelos.Jugador;
import modelos.ListaJugadores;
import modelos.Usuario;
import vistas.Comando;

public class CrearJugador extends Comando {
    private final ListaJugadores listaJugadores;
    public CrearJugador(ListaJugadores listaJugadores){
        super("player-create");
        this.listaJugadores= listaJugadores;
}

    public void ejecutar(String[] args) {
        assert args.length >= 4 : "Error: No se han proporcionado suficientes argumentos.";
        Usuario usuario = UsuarioSesion.getUsuarioActual();
        assert usuario != null : "Error: No se ha autenticado un usuario.";

        String nombre = args[1].toLowerCase().trim();
        String apellidos = args[2].toLowerCase().trim();
        String dni = args[3].toUpperCase().trim();
        Jugador existingPlayer = listaJugadores.buscarPorNombre(nombre);
        if (existingPlayer != null) {
            System.out.println("Error: Jugador ya existente con el DNI " + dni);
            return;
        }

        Jugador jugador = new Jugador(nombre,apellidos, dni, usuario);
        listaJugadores.agregarJugador(jugador);
        System.out.println("Jugador creado con éxito: " + nombre + " " + apellidos);
    }
}

