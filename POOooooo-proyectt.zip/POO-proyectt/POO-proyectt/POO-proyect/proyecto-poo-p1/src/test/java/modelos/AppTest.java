package modelos;

import GestionDeportiva.GestionDeportiva;
import org.junit.jupiter.api.Test;

class AppTest {
    @Test
    void testApp(){
        new GestionDeportiva();
    }
}
